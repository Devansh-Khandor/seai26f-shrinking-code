T1-T6 treatment runs, protocol v2, model gpt-oss-20b, 3 trials, domains cars / nasa / apache.

RUN_ENV.md                       model, server settings, library versions, harness commit
results/runs.csv                 one row per step (540 rows); columns explained in harness/README.md
results/requirements.csv         semantic verdict for every request of every step (1080 rows)
results/regrade.txt              verdicts changed by `python -m harness.regrade --skills 5,6`
results/*.pre-regrade.csv        runs.csv and requirements.csv as they were before that re-grade
results/gpt-oss-20b/             summary tables from `python -m harness.analyze`:
    same_tables.md               T2 vs T1, T4 vs T3, T6 vs T5 (primary = per-trial totals, secondary = pooled)
    histogram.md/.csv            median % new code per step
    pass_rates.md                runs / contract / semantic pass rates and failure categories
    requirements.md              request-level semantic pass rates
    sizing.md                    max prompt tokens per step

runs/gpt-oss-20b/<domain>/<treatment>/trial<k>/
    stepNN/                      the trial's complete code after skill NN
    stepNN.prompt.txt            exactly what was sent to the model
    stepNN.response.txt          exactly what the model replied
    stepNN.check.txt             stdout/stderr of running the program on the domain CSV
    stepNN.semantic.json         semantic checker evidence: answers on the real data and on the
                                 controlled copies (shuffled, mask, future, honeypot)
    stepNN.semantic.pre-regrade.json   the evidence before the re-grade (skills 5 and 6 only)

A step with status parse_failed has no stepNN.check.txt; its stepNN/ is a copy of the previous step.
The same trials are git tags v2-<t#>-<domain>-r<trial>-step<k> in the repository.
Machine-specific paths were replaced with <tmp>, <repo>, <home> and <python>.
