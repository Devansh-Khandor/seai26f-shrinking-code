# Run environment (protocol v2)

| Field | Value |
|---|---|
| Date | 2026-11-18 (steps timestamped 06:00 to 10:11 UTC) |
| Offload | all layers on the GPU (`-ngl 99`) |
| OS | Windows 11 (x86_64) |
| Python version | 3.13.7 (venv from `requirements.txt`) |
| scikit-learn version | 1.9.1 (numpy 2.5.4) |
| Lua | not used: v2 T5/T6 use the Python ezr in `harness/vendor/` |
| Backend | `llamacpp` (`llama-server`, OpenAI-compatible endpoint) |
| llama.cpp build | b12242 (commit 3b4d6ab3f), recorded per step in `runs.csv` `model_digest` |
| `llama-server` command line | `llama-server -m gpt-oss-20b-MXFP4.gguf -c 65536 -np 1 -ngl 99 --jinja --temp 1.0 --top-p 1.0 --port 8080` (same server as v1) |
| GGUF file + SHA256 | `gpt-oss-20b-MXFP4.gguf`, `27cd6c432c7672cb812a92f611cf3ba7bbc35928262bb1e1253ff4ee6ae35901` |
| Model tag | gpt-oss-20b (`--think medium`) |
| Quantization | MXFP4 |
| Context | 65536 |
| Temperature | 1.0 (top-p 1.0, set on the server) |
| Harness commit (run) | d6de7ab |
| Harness commit (re-grade of skills 5-6) | 1a127e6 |
| `prompt_template_hash` (from runs.csv) | c98c01d01869 |
