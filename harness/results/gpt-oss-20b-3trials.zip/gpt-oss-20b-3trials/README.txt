T1-T6 treatment runs, model gpt-oss-20b, 3 trials, domains cars / nasa / apache.

RUN_ENV.md                 model, server settings, library versions, harness commit
results/runs.csv           one row per step (540 rows); columns explained in harness/README.md
results/gpt-oss-20b/       summary tables from `python -m harness.analyze`:
    same_tables.md         T2 vs T1, T4 vs T3, T6 vs T5 (primary = per-trial totals, secondary = pooled)
    histogram.md/.csv      median % new code per step
    pass_rates.md          tier 1 (runs) and tier 2 (output contract) pass rates
    sizing.md              max prompt tokens per step

runs/gpt-oss-20b/<domain>/<treatment>/trial<k>/
    stepNN/                the trial's complete code after skill NN
    stepNN.prompt.txt      exactly what was sent to the model
    stepNN.response.txt    exactly what the model replied
    stepNN.check.txt       stdout/stderr of running the program on the domain CSV

A step with status parse_failed has no stepNN.check.txt; its stepNN/ is a copy of the previous step.
Machine-specific paths in check.txt were replaced with <tmp>, <repo>, <home> and `lua`.
